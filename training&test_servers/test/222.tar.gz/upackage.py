import os
import gzip
import rarfile
import zipfile
import tarfile
import tarfile

def unpackage(file_path, extract_dir):
    ext = file_path.split('.')[-1]
    if ext == '.zip':
        """unzip zip file"""
        zip_file = zipfile.ZipFile(file_path)
        if  not os.path.isdir(extract_dir):
            os.mkdir(extract_dir)
        for names in zip_file.namelist():
            zip_file.extract(names, extract_dir)
        zip_file.close()
        # os.rename(extract_dir, dataset_dir)

    if ext == '.rar':
        """unrar zip file"""
        rar = rarfile.RarFile(file_path)
        if not os.path.isdir(extract_dir):
            os.mkdir(extract_dir)
        os.chdir(extract_dir)
        rar.extractall()
        rar.close()

    if ext == '.gz':
    """ungz zip file"""
    f_name = file_path.replace(".gz", "")
    g_file = gzip.GzipFile(file_path)
    open(f_name, "w+").write(g_file.read())
    g_file.close()
    """untar zip file"""
    tar = tarfile.open(file_path)
    names = tar.getnames()
    if os.path.isdir(file_path + "_files"):
        pass
    else:
        os.mkdir(file_name + "_files")
    for name in names:
        tar.extract(name, file_name + "_files/")
    tar.close()


    if ext == '.tar':
    """untar zip file"""
    tar = tarfile.open(file_path)
    names = tar.getnames()
    if os.path.isdir(file_path + "_files"):
        pass
    else:
        os.mkdir(file_name + "_files")
    for name in names:
        tar.extract(name, file_name + "_files/")
    tar.close()