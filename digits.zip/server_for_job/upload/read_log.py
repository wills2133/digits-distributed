import os

os.path.exists()