import os
import time 

if os.path.exists('./test.log'):
	f = open('./test.log', 'r')
	lines = f.readlines()
	f.close()


for line in lines:
	f2 = open('./create.log', 'a+')
	f2.write(line)
	time.sleep(1)
	f2.close
