#!/usr/bin/env python
# coding=utf-8

import os
import threading
import model_server
from flask import Flask, request, render_template as rt

app = Flask(__name__)

class thread_flask_run(threading.Thread):
    def __init__(self, ip, port):
        threading.Thread.__init__(self)
        self.ip = ip
        self.port = port
    def run(self):
        try:
            app.run(self.ip, self.port)
        except Exception as thread_err:
            print ('Upload server thread Error: {}'.format(thread_err) )
            print ('Upload server thread was interupted')
            return 

@app.route('/', methods=['GET', 'POST'])
def index():  # 一个分片上传后被调用
    if request.method == 'POST':
        upload_file = request.files['file']
        task = request.form.get('task_id')  # 获取文件唯一标识符
        chunk = request.form.get('chunk', 0)  # 获取该分片在所有分片中的序号
        filename = '%s%s' % (task, chunk)  # 构成该分片唯一标识符
        upload_file.save('./upload/%s' % filename)  # 保存分片到本地
    return rt('./index.html')


@app.route('/success', methods=['GET'])
def upload_success():  # run after all the chunks is upload
    task = request.args.get('task_id')
    ext = request.args.get('ext', '')
    upload_type = request.args.get('type')
    if len(ext) == 0 and upload_type:
        ext = upload_type.split('/')[1]
    ext = '' if len(ext) == 0 else '.%s' % ext  # construct file name
    chunk = 0
    with open('./upload/%s%s' % (task, ext), 'w') as target_file:  # crate new files
        while True:
            try:
                filename = './upload/%s%d' % (task, chunk)
                source_file = open(filename, 'r')  # open chunks in order
                target_file.write(source_file.read())  # fill the new file with chunks
                source_file.close()
            except IOError:
                break
            chunk += 1
            os.remove(filename)  # delect chunks
    return rt('./index.html')

def mian():
    pass

if __name__ == '__main__':

    dataset_id = '0.0.0.0'
    dataset_port = 2134
    model_id = '0.0.0.0'
    model_port = 2133

    try:
        flask_run = thread_flask_run(dataset_id, dataset_port)
        flask_run.start()
        model_server.run_training_server(model_id, model_port)
    except KeyboardInterrupt:
        print 'error'
    #     return
    # mian()