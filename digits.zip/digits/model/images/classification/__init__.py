# Copyright (c) 2014-2017, NVIDIA CORPORATION.  All rights reserved.
from __future__ import absolute_import

from .job import ImageClassificationModelJob

__all__ = ['ImageClassificationModelJob']
