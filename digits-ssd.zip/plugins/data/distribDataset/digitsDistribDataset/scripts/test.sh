#!/bin/bash

cur_dir=$(cd $( dirname ${BASH_SOURCE[0]} ) && pwd )
# root_dir=$cur_dir/../..
root_dir=$CAFFE_ROOT

cd $root_dir
