# Copyright (c) 2014-2017, NVIDIA CORPORATION.  All rights reserved.
from __future__ import absolute_import

import flask

blueprint = flask.Blueprint(__name__, __name__)
