import time
import sys
n=0
while n  < 2:
	print n
	# sys.stdout.write(str(n))
	n+=1
	time.sleep(1)
	# if n > 9:
	# 	break