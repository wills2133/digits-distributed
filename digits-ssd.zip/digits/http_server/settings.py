# change these values as you see fit
# after running `sudo ./install`, the server should run at http://host:port/base_url
host = '127.0.0.1'
port = 1022
base_url = 'some_preferred_url/'
username = '1234'
password = '1234'

# for example, with above default values, the server should run at 127.0.0.1:5000/some_preferred_url/
